# CSE-628-Assignment-1-NLP

The folder includes the folling files:
1. Code : 
CSE 628  Assignment 1.ipynb 
The ipython notebook can be viewed using the following link : 
http://nbviewer.ipython.org/github/nups111/CSE-628-Assignment-1-NLP/blob/master/CSE%20628%20%20Assignment%201.ipynb

2. Report:
  The Report includes the evaluation and analysis for Part I and Part II
  
3. Experimental Results: 
The experimental results are stored in three tsv files :
a. part-I-predictions.tsv
b. Method-A-predictions.tsv
c. Method-B-predictions.tsv
